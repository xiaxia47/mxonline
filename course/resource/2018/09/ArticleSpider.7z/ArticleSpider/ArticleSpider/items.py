# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy.loader.processors import MapCompose, TakeFirst, Join
from scrapy.loader import ItemLoader
import datetime
from ArticleSpider.utils.commons import extract_num
from .settings import SQL_DATETIME_FORMAT,SQL_DATE_FORMAT

def load_create_date(value):
    value = value.replace('·', '').strip()
    try:
        value = datetime.datetime.strptime(value,"%Y/%m/%d").date()
    except Exception as e:
        value = datetime.datetime.now()
    return value


def remove_comment_tags(value):
    return "" if "评论" in value else value



class ArticleItemLoader(ItemLoader):
    default_output_processor = TakeFirst()


class JobBoleArticleItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    title = scrapy.Field()
    create_date = scrapy.Field(
        input_processor=MapCompose(load_create_date))
    url = scrapy.Field()
    url_object_id = scrapy.Field()
    front_image_url = scrapy.Field(
        output_processor=MapCompose(lambda value: value)
    )
    front_image_path = scrapy.Field()
    praise_nums = scrapy.Field(
        input_processor=MapCompose(extract_num)
    )
    comment_nums = scrapy.Field(
        input_processor=MapCompose(extract_num)
    )
    fav_nums = scrapy.Field(
        input_processor=MapCompose(extract_num)
    )
    tags = scrapy.Field(
        input_processor=MapCompose(remove_comment_tags),
        output_processor=Join(','))
    content = scrapy.Field()

    def get_sql(self):
        insert_sql = (" insert into jobbole_article(title,url,url_object_id,create_date,fav_nums) "
                      " values(%s,%s,%s,%s,%s)")
        parms =(self['title'], self['url'], self['url_object_id'],
                self['create_date'], self['fav_nums']
        )
        return insert_sql, parms

class ZhihuQuestionItem(scrapy.Item):
    zhihu_id = scrapy.Field()
    topics = scrapy.Field()
    url = scrapy.Field()
    title = scrapy.Field()
    content = scrapy.Field()
    answer_num = scrapy.Field()
    comments_num = scrapy.Field()
    watch_user_num = scrapy.Field()
    click_num = scrapy.Field()
    crawl_time = scrapy.Field()

    def get_sql(self):
        insert_sql = """
            insert into zhihu_question(zhihu_id,topics,url,title,content,create_time,
                        answer_num,comments_num,watch_user_num,click_num,
            crawl_time) values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) 
            ON DUPLICATE KEY UPDATE content=VALUES(content), answer_num=VALUES(answer_num), 
            comments_num=VALUES(comments_num),watch_user_num=VALUES(watch_user_num), 
            click_num=VALUES(click_num),crawl_time=VALUES(crawl_time)
            """
        zhihu_id = self['zhihu_id'][0]
        topics = self['topics'][0]
        url = self['url'][0]
        title="".join(self['title'])
        content = ",".join(self['content']) if 'content' in self else ""
        if len(self['watch_user_num']) == 2:
            watch_user_num = int(self['watch_user_num'][0])
            click_num = int(self['watch_user_num'][1])
        else:
            watch_user_num = int(self['watch_user_num'][0])
            click_num = 0
        answer_num = extract_num(self['answer_num'][0])
        comments_num = extract_num(self['comments_num'][0])
        crawl_time = datetime.datetime.now().strftime(SQL_DATETIME_FORMAT)
        create_time = datetime.datetime.now().strftime(SQL_DATETIME_FORMAT)
        parms =(zhihu_id, topics, url, title, content, create_time,
                answer_num, comments_num, watch_user_num,
                click_num, crawl_time
                )
        return insert_sql, parms

class ZhihuAnswerItem(scrapy.Item):
    zhihu_id = scrapy.Field()
    url = scrapy.Field()
    question_id = scrapy.Field()
    author_id = scrapy.Field()
    content = scrapy.Field()
    parise_num = scrapy.Field()
    comments_num = scrapy.Field()
    update_time = scrapy.Field()
    create_time = scrapy.Field()
    crawl_time = scrapy.Field()

    def get_sql(self):
        insert_sql = """
            insert into zhihu_answer(zhihu_id,url,question_id,content,author_id,
                        content,parise_num,comments_num,create_time,update_time,
            crawl_time) values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) 
            ON DUPLICATE KEY UPDATE content=VALUES(content), parise_num=VALUES(parise_num), 
            comments_num=VALUES(comments_num),crawl_time=VALUES(crawl_time)
            """

        parms =(self['zhihu_id'], self['url'], self['question_id'], self['content'],
                self['author_id'],self['create_time'],self['answer_num'],
                self['comments_num'], self['watch_user_num'],self['click_num'],crawl_time
                )
        return insert_sql, parms

