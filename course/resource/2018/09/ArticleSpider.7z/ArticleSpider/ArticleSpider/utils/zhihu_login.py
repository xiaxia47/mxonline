# _*_ coding:utf-8 _*_
from requests import Session
import requests
from requests_toolbelt import MultipartEncoder
import http.cookiejar as cookielib
import time
import hmac
import hashlib
import re

HEADER = {'Accept':'application/json, text/plain, */*',
    'Accept-Encoding':'gzip, deflate',
    'Accept-Language':'zh-CN,zh;q=0.9',
    'User-Agent':'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36',
    'origin':'https://www.zhihu.com',
    'pragma':'no-cache',
    'cache-control': 'no-cache',
    'referer':'https://www.zhihu.com/signup?next=%2F',
}

def zhihuLogin(username,password):
    signin_url = 'https://www.zhihu.com/api/v3/oauth/sign_in'
    main_page = 'https://www.zhihu.com/signup?next=%2F'
    source = "com.zhihu.web"
    grant_type = "password"
    s = Session()
    s.cookies = cookielib.LWPCookieJar(filename='cookies.txt')
    try:
        print(f"Loading cookies from {s.cookies.filename}")
        s.cookies.load(ignore_discard=True)
        if is_login(s.cookies):
            return {cookie.name:cookie.value for cookie in s.cookies}
    except:
        print("cookie loaded failed, processing logining.")
    s.headers.update(HEADER)
    mid_head = dict()
    main_response = s.get(main_page)
    mid_head['x-udid'] = main_response.cookies['d_c0'].split('|')[0].replace('"','')
    mid_head['x-xsrftoken'] = main_response.cookies['_xsrf']
    #获取capsion 数据
    s.headers.update({"x-udid":mid_head['x-udid']})
    resp = s.get('https://www.zhihu.com/api/v3/oauth/captcha?lang=en')
    print(resp.text)
    client_id, authorization, key = analyzeMainJs(s,main_response.text)
    timestamp = str(int(time.time()))
    sign = getSign(key, grant_type, client_id, source, timestamp)
    md_data,mid_head['Content-Type'] = getmulitPart(client_id, grant_type, source, timestamp,sign,username,password)
    s.headers.update(mid_head)
    resp = s.post(signin_url, data=md_data)
    s.cookies.save()
    if resp.status_code != 201 and resp.status_code != 200:
        raise Exception("Loging failed")
    return {cookie.name:cookie.value for cookie in s.cookies}

def analyzeMainJs(session,page):
    main_js_url_pattern = r'script src\=\"(https\:\/\/static\.zhihu\.com\/heifetz\/main\.app\..{20}\.js)\"'
    main_js_url = re.search(main_js_url_pattern,page).group(1)
    resp = session.get(url=main_js_url)
    if resp.status_code != 200:
        raise Exception('Error on getting main js url')
    main_js = resp.text
    auth_pattern = r'authorization\:\"oauth (.{32})\"'
    client_id = re.search(auth_pattern,main_js).group(1)
    sign_key_pattern = r'setHMACKey\(\"(\w+)\"\,'
    key = re.search(sign_key_pattern,main_js).group(1)
    return [client_id, " ".join(['oauth',client_id]),key]

def getSign(key, grant_type, client_id, source, timestamp):
    sign = hmac.new(bytes(key,'utf-8'),digestmod=hashlib.sha1)
    sign.update(bytes(grant_type,'utf-8'))
    sign.update(bytes(client_id,'utf-8'))
    sign.update(bytes(source,'utf-8'))
    sign.update(bytes(timestamp,'utf-8'))
    return sign.hexdigest()


def getmulitPart(client_id,grant_type,source,timestamp,signature,username,password):
    m = MultipartEncoder(
        fields={"client_id":client_id,
                "grant_type":grant_type,
                "timestamp":timestamp,
                "source":source,
                "signature":signature,
                "username":username,
                "password":password,
                "captcha":"",
                "lang":"cn",
                "ref_source":"homepage",
                "utm_source":""})
    return [m,m.content_type]

def is_login(cookies):
    account_setting_url = "https://www.zhihu.com/settings/account"
    resp = requests.get(url=account_setting_url,headers=HEADER,
                       allow_redirects=False,cookies=cookies)
    if resp.status_code != 200:
        return False
    else:
        return True

if __name__ == "__main__":
    zhihuLogin('13801991222','sx21958')