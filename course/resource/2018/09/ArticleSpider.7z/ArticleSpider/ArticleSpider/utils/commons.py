#_*_ coding:utf-8 _*_
import hashlib
import re


def get_md5(url):
    if isinstance(url, str):
        url = url.encode('utf-8')
    m = hashlib.md5()
    m.update(url)
    return m.hexdigest()


def extract_num(value):
    #从字符串中提取数字
    try:
        value = value.replace(',','')
        re_obj = re.search(r'\d+',value)
        return int(re_obj.group(0)) if re_obj else 0
    except Exception as e:
        raise e


if __name__ == '__main__':
    print(get_md5('http://jobbole.com').encode('utf-8'))